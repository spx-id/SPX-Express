# Pusat Bantuan Pengiriman (Landing Page)

Single-file landing page untuk informasi & panduan pelanggan.
**Bukan layanan resmi Shopee / Shopee Express.**

## Cara Deploy ke GitHub Pages (cepat)
1. Buat repo baru di GitHub, contoh: `pusat-bantuan-pengiriman`.
2. Upload semua file di folder ini (index.html, .nojekyll, README.md).
3. Masuk **Settings → Pages**:
   - **Source**: pilih **Deploy from a branch**.
   - **Branch**: pilih `main` dan folder `/ (root)` → **Save**.
4. Tunggu build ±1 menit. Situs akan tersedia di:
   - `https://<username>.github.io/pusat-bantuan-pengiriman/`

## Kustomisasi
- Edit teks/CTA di `index.html`.
- (Opsional) Tambah `CNAME` berisi domain kustom untuk custom domain.

## Keamanan & Kepatuhan
- Sertakan disclaimer di halaman (sudah ada).
- Jangan menampilkan logo/merek resmi tanpa izin.